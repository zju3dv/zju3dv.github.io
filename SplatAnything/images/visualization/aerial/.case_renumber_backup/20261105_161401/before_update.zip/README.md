# SplatAnything 项目主页模板

纯 HTML / CSS / JavaScript，无需构建，可以直接作为 GitHub Pages 子目录部署。

## 本地预览

在当前目录运行：

```sh
python3 tools/serve.py 8080
```

然后访问 `http://localhost:8080`。该预览服务支持 HTTP Range 分段请求，使视频在尚未全部下载时也能使用分类按钮跳转或拖动进度条。不要用不支持 Range 的普通 `python3 -m http.server` 预览视频。也可以直接打开 `index.html` 查看静态内容；视频和 3D 交互应通过 HTTP 服务验证。

## 内容入口

作者、单位及后续素材地址在 **`assets/js/content.js`** 中维护。作者和单位已填写，副标题当前在 `index.html` 中；其余论文内容和素材地址待补充。页面中的几何缩略图只是模板，不是真实实验结果。单位按数组顺序自动标注为 1、2，作者的 `affiliation` 使用对应编号，多单位用逗号分隔。

| 字段                   | 用途                                                                                  |
| ---------------------- | ------------------------------------------------------------------------------------- |
| `project.subtitle`     | 论文副标题；出现 Gaussian Spacing Normalization 时自动突出显示                        |
| `project.authors`      | 作者数组，例如 `{ name: '姓名', url: '作者主页', affiliation: '1' }`                  |
| `project.affiliations` | 单位名称数组                                                                          |
| `project.links`        | `paper`、`code`、`huggingface` 分别对应 Paper、Code、HuggingFace Demo；留空时不可点击 |
| `tldr`                 | 第一模块的简介，支持换行，按纯文本处理                                                |
| `video.src`            | 视频文件地址，例如 `assets/media/demo.mp4`                                            |
| `video.poster`         | 视频封面图片                                                                          |
| `video.embed`          | 视频平台的嵌入播放器地址，`src` 有值时优先使用本地视频                                |
| `video.caption`        | 可选视频说明                                                                          |
| `video.aspectRatio`    | 可选视频比例，例如 `"3 / 2"`；有视频时默认 `16 / 9`                                   |
| `video.chapters`       | 视频下方的分类跳转按钮，例如 `{ id: 'object', label: 'Objects', time: 5 }`，`time` 单位为秒 |
| `qualitative`          | Objects / Indoor / Street / Aerial 四个类别；场景默认来自 `images/visualization`，见下文 |
| `comparison.methods`   | 右栏可选择的方法，`id` 必须唯一                                                       |
| `comparison.categories`| 对比的四个类别，每个场景含 Ours 与各方法的结果                                         |
| `acknowledgements`     | 致谢：`text` 为正文，`links` 中列出的人名会在正文中自动变成链接；`text` 为空时隐藏板块 |
| `citation`             | 引用的 BibTeX 文本，Copy 按钮复制到剪贴板；为空时隐藏板块                              |

类别和场景数量都不固定，可以直接增删数组中的元素。类别 `id` 为 `object`、`indoor`、`street`、`aerial` 时自动使用对应图标。场景 `id` 必须唯一；缩略图网格、当前选中状态、场景计数都会自动更新。切换类别时保留各类上一次选择的场景。

Demo 视频使用 `demo/SplatAnything_demo_web.mp4`（H.264、1080p、索引前置，便于渐进播放），原始 HEVC 视频保留在同目录。页面打开后会预加载视频，视频中央显示旋转圆圈和缓冲百分比，可以播放后自动隐藏，播放或跳转时需要缓冲则再次显示；视频底部不显示加载状态栏。百分比根据浏览器实际已缓冲的时长计算，跳转后有多个缓冲区间时按总时长计算。具体预加载量由浏览器和网络条件决定，播放和跳转不必等待整个视频下载完成。加载失败时可重试或直接打开视频。

Demo 视频加载前的底图 `demo/poster.jpg` 使用该视频的第一帧。

视频下方四个按钮分别跳到 Objects（00:05）、Indoor Scenes（00:15）、Street Scenes（00:26）、Aerial Scenes（00:38）并开始播放；当前播放的分类会同步高亮。时间戳在 `video.chapters` 中维护。

## 展示方式（参考 InfiniSplat v2）

Method 板块位于 Demo Video 与 Qualitative Results 之间，正文和图注在 `index.html` 中维护：图 (a) 为 `images/method/pipeline_2.jpg`，展示整体流程；图 (b) 为 `pipeline_1.jpg`，解释 RDNorm 的 Gaussian-scale 监督歧义和 GSNorm 的作用。文字依据本地论文的 Abstract 和 Introduction 整理。两图保持完整比例，Full size 链接可打开原图；手机端图注按单列显示。

对比模块目前暂时停用，HTML、样式、脚本和内容配置均保留。重新启用时，取消 `index.html` 中对比 section 和 Compare 导航的注释，以及 `assets/js/app.js` 中 `setupComparison()` 调用的注释。

第 3、4 模块参考 [InfiniSplat v2](https://zju3dv.github.io/InfiniSplat2/) 的 Visualization：选中场景后先显示 `poster` 和静音循环的 `preview` 视频，点击 **Explore in 3D** 才加载 SuperSplat 查看器；**Back to preview** 返回预览，右上角箭头在新标签页打开查看器。场景卡片以网格排在查看器下方，每个类别可以放很多例子而不会一次下载所有模型。

- `preview` 建议使用几秒钟、H.264 编码的 MP4。只在查看器进入视口附近时下载，离开视口、页面进入后台或 Demo 视频播放时暂停；系统开启“减少动态效果”时只显示静帧。
- 上方播放器的加载底图 `poster.jpg` 使用预览视频第一帧；下方场景卡片的 `thumb.jpg` 继续使用目录内原来的源图片。没有视频时，播放器底图也使用源图片；没有独立图片时，卡片缩略图才回退到视频首帧。
- 每个场景可选 `aspectRatio`（例如 `"4 / 3"`），让查看器比例与素材一致；默认结果区 `16 / 9`，对比区 `1.26`。
- 预览图比例与查看器不同时，两侧用同一张图的模糊版本填充。
- 只有 `viewer` 没有图片时显示占位背景加 Explore 按钮；三者都为空时显示 “3D scene coming soon” 占位。

## 3D 查看器（本地验证 / HuggingFace 托管）

每个场景的 3D 结果是一个用 SuperSplat 导出的**单文件 HTML 查看器**（模型已压缩并内嵌在 HTML 中）。当前 Object 的 HTML 暂存于各场景目录，用于本地验证；后续可以转移到 HuggingFace 托管。

本地验证时，将 HTML 放到 `images/visualization/<类别>/<编号>/` 后运行同步脚本。脚本自动记录 `localViewer` 和远程 `viewer` 路径（保留 HTML 文件名，有多个 HTML 时优先选择 `viewer.html`）。`viewerBase` 留空时，点击 **Explore in 3D** 才在 iframe 中加载本地 HTML。当前 Object 和 Indoor 各 12 个场景均已提供 `preview.mp4`，会在预览区域静音循环播放，点击 **Back to preview** 可从 3D 视图返回。目录中有多个视频时优先使用 `preview.mp4` / `preview.webm`。

1. 在 SuperSplat 中导入 PLY，调整初始相机，导出单文件 HTML 查看器。
2. 上传到 HuggingFace 仓库（dataset 或 model 均可），使用生成的 `viewer` 路径：`<类别>/<编号>/<HTML文件名>`。例如 Object 09 为 `object/9/box_109__wcam_wintrs.html`。没有本地 HTML 的场景仍默认使用 `<类别>/<编号>/viewer.html`。
3. 在 `assets/js/content.js` 中填写 `viewerBase`，即仓库文件的根地址：

```js
viewerBase: "https://huggingface.co/datasets/<user>/<repo>/resolve/main/",
```

`viewerBase` 为空且没有本地 HTML 时，结果区显示预览图和 “3D VIEWER SOON”。填写 `viewerBase` 后会优先使用远程文件，无需修改每个场景；点击 **Explore in 3D** 后才由 `assets/viewer/loader.html` 从 HuggingFace 下载对应 HTML（显示 MB 进度），下载完成后在 iframe 中由 SuperSplat 运行。HuggingFace 的 `resolve` 地址会把 HTML 当作下载文件，不能直接放进 iframe，所以需要这个 loader（与 InfiniSplat v2 相同的做法）。右上角“在新标签页打开”同样经过 loader。`info.json` 中的完整 `viewer` URL 或显式本站路径仍优先，`viewer: ""` 可关闭该场景的 3D 功能。

建议在 `resolve/` 后用固定的 commit hash 代替 `main`，以免更新仓库后浏览器缓存不一致。

`viewer` 的地址规则：

- 普通相对路径（如 `object/1/viewer.html`）相对于 `viewerBase`；
- 完整 URL，或以 `/`、`./`、`../` 开头的本站路径，按原样使用；
- 与页面不同源的地址自动经过 loader，本站地址直接放进 iframe。

## 定性结果素材（images/visualization）

Qualitative Results 的场景由 `images/visualization/<类别>/<编号>/` 自动生成，类别目录为 `object`、`indoor`、`street`、`aerial`，仅扫描纯数字命名的场景目录并按数字顺序排列，忽略 `video/` 等原始导出或辅助目录。每个场景目录可放：

| 文件 | 用途 |
| ---- | ---- |
| 任意一张图片（`.png` / `.jpg` / `.webp`） | 下方场景卡片的源图片，生成 `thumb.jpg`（480px）；没有视频时也生成播放器底图 `poster.jpg`（1280px） |
| `*.mp4` / `*.webm` | 选中场景后静音循环播放；第一帧只用于上方播放器的加载底图 `poster.jpg`（建议几秒钟、H.264） |
| `*.html` | 本地验证用的 SuperSplat 查看器；自动接入 Explore in 3D，未来上传时保留相同文件名 |
| `info.json`（可选） | `{"name": "...", "dataset": "...", "viewer": "..."}`：覆盖默认名称（`Object 01` 等）或查看器路径；`"viewer": ""` 表示该场景没有 3D |

有本地 HTML 时，`viewer` 为 `<类别>/<编号>/<HTML文件名>`，`localViewer` 为本站素材路径；否则 `viewer` 默认为 `<类别>/<编号>/viewer.html`。增删或修改素材后运行：

```bash
python3 -m pip install pillow imageio-ffmpeg
python3 tools/sync_gallery.py
```

脚本会重新生成 `assets/js/gallery.js`，`content.js` 中的 `qualitative` 直接读取它。有视频时生成对应第一帧的播放器底图，卡片缩略图保留原图。`preview-frame.json` 记录视频文件名、大小和修改时间，视频变化后自动重新提取底图；系统已有 ffmpeg 时无需安装 imageio-ffmpeg。原始 PNG 只作为源文件，页面只加载生成的 JPG。不要把 PLY 放进本仓库。

Object 已按当前展示顺序整理为 `images/visualization/object/1/` 至 `12/`，已移除 case 的素材目录已删除。文件夹编号、场景 ID、预览图路径和默认名称 `Object 01` 至 `Object 12` 一一对应，直接按目录数字顺序同步。`info.json` 中的自定义名称优先，新增场景时继续使用后续编号即可。

Indoor 保留原目录 `1, 2, 4, 5, 7, 10, 11, 12, 15, 16, 19, 20`，已依次整理为 `indoor/1/` 至 `12/`，页面名称对应 `Indoor 01` 至 `Indoor 12`。HTML 查看器保留原文件名，所在目录和生成的查看器路径使用新编号。

Street 当前为 `street/1/` 至 `12/`，页面名称对应 `Street 01` 至 `Street 12`，各目录的 `preview.mp4` 用于静音循环预览。播放器加载底图使用视频首帧，下方卡片图使用原始图片；`video/` 和 `video.zip` 保留为原始导出素材，不参与场景生成。

手动填写的定性场景示例：

```js
{
  id: 'indoor-01',
  name: '场景名称',
  dataset: '数据集名称',
  poster: 'assets/media/indoor-01.jpg',
  preview: 'assets/media/indoor-01.mp4',
  viewer: 'indoor/1/viewer.html', // 相对于 viewerBase
  aspectRatio: '4 / 3', // 可选
}
```

对比填写示例：

```js
methods: [
  { id: 'model-a', name: '方法名称' },
],
categories: [
  {
    id: 'street',
    label: 'Street Scenes',
    scenes: [
      {
        id: 'compare-street-01',
        name: '场景名称',
        dataset: '',
        thumbnail: '', // 可选，默认使用 Ours 的 poster
        ours: {
          poster: 'assets/media/compare-street-01/ours.jpg',
          preview: 'assets/media/compare-street-01/ours.mp4',
          viewer: 'compare/street-01/ours.html', // 相对于 viewerBase
        },
        models: {
          // 也可以只写查看器地址字符串
          'model-a': 'compare/street-01/model-a.html',
        },
      },
    ],
  },
],
```

对比区与结果区使用同一套类别标签和场景网格，左侧固定 Ours，右侧下拉框切换方法，不重载左栏。点击任一侧的 Explore in 3D 会同时打开两侧的查看器，**Back to previews** 同时返回预览；切换场景或类别时两侧回到预览。右侧预览视频跟随左侧的播放时间，方便对比相同的相机轨迹。某个方法的结果留空时，仅该栏显示占位状态，不沿用上一场景的结果。

**相机说明：**两栏是独立的 SuperSplat 页面，当前没有跨 iframe 相机同步。为保证初始视角一致，请在导出每个方法的结果时使用相同坐标系、相机位置和朝向。重置按钮通过重载对应查看器恢复导出的初始状态。外部页面可能受自己的嵌入策略限制，应使用允许 iframe 展示的地址。

父页面只在展示区接近视口时加载查看器，换场景时移除旧 iframe。HuggingFace 上的 HTML 由 loader 显示下载进度，下载失败（例如 404）时提供重试和直接下载链接。上传后建议先在新标签页打开确认可用。

## 设计和维护

页面有两套设计，共用同一份 `assets/js/content.js`、素材和字体：

| 设计 | 入口 | 样式 / 脚本 |
| --- | --- | --- |
| 当前：简洁浅色（默认） | `index.html` | `assets/css/style.css`、`assets/js/app.js` |
| 原版：暖灰窗口风格 | `index-classic.html` | `assets/css/style-classic.css`、`assets/js/app-classic.js` |

原版文件是改版前的完整冻结副本，不要再改动。直接访问 `index-classic.html` 即可查看原版；要把原版换回主页，执行：

```sh
mv index.html index-light.html && mv index-classic.html index.html
```

（`index-classic.html` 引用的是 `-classic` 版样式和脚本，改名后仍然有效。）

**当前设计**参考 learn.shareai.run 的配色：白色底、`#f4f4f5` 浅灰面板、`#e4e4e7` 细边框、`#09090b` 正文和 `#71717a` 次要文字；主按钮与类别分段控件选中态为近黑色；Demo 视频和 BibTeX 放在带红黄绿三点的黑色窗口里；四个类别分别使用浅蓝、浅绿、浅琥珀、浅紫徽章（场景编号与数据集标签随类别变色）。正文使用系统字体栈（Apple 设备上为 SF Pro / SF Mono），项目名 SplatAnything 沿用原版的 Georgia 斜体；副标题在宽度 1000px 以上的屏幕保持一行，更窄时自动换行。标题居中。首屏保留原版的 “Splat” 标题特效：每 9 秒短暂散开成椭圆色斑再聚合（近黑色斑点，约六分之一为蓝色点缀），鼠标移入可重播，标签旁的圆形按钮可暂停；标题离开视口或页面进入后台时自动暂停，系统开启“减少动态效果”时显示静态标题。

- `index.html`：首屏与概览、视频、Method、结果、致谢、引用模块；对比模块保留代码，当前已注释停用。
- 主标题右上角的 ♾️ 标志使用 SVG 和蓝色流动线段动画，随标题字号缩放，并与标题的暂停按钮、离开视口暂停及“减少动态效果”设置同步。
- `assets/css/style.css`：当前设计的全部样式，颜色集中在文件开头的变量中。
- `assets/js/app.js`：内容渲染、类别与场景切换、预览与查看器切换、双栏对比、加载、全屏和引用复制。
- `assets/favicon.svg`：标签页图标，与标题右上角共用同款黑色轮廓、蓝色线段的 ♾️ 造型。

**原版设计**为暖灰底色 `#e4e4e0`、悬浮导航、斜体项目名，以及 “Splat” 散开再聚合的标题动画；它使用 `assets/fonts/` 中的 DM Sans 和 IBM Plex Mono。

几何缩略图和视频占位只是模板，不代表实验结果。页面功能不依赖第三方 JavaScript。

模板包含键盘操作：Tab 聚焦控件；类别标签支持左右方向键、Home、End，场景网格还支持上下方向键按行移动；全屏支持关闭按钮和 Esc。窄屏保留两栏对比，通过全屏按钮可放大各自的查看器。
